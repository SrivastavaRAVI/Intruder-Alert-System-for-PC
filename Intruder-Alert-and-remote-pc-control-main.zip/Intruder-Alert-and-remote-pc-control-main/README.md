# Intruder-Alert-and-remote-pc-control
This program tells the user when someone else is using their pc, it takes photographs and sends them to the user's phone via email, and in response, the user can show warning messages remotely to the intruder also he can shut down his system with his phone.
Time Lapse: https://youtu.be/PYIkADCUQNw
